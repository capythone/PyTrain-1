##### try as exercise

### while , while with else

counter = 0

while counter < 3:
    print("Inside loop")
    counter += 1
    break
else:
    print("Inside else")