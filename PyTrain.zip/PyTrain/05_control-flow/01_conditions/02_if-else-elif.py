word = "rocket cience"
if "a" in word:
    print(word + " contains the letter a")
elif "s" in word:
    print(word + " contains the letter s")
else:
    print("What a weird word!")

# WAP that defines a variable weight.
# If the weight is > 50 pounds, print "There is a $25 charge for luggage that heavy."
# If it is not, print: "Thank you for your business."
# Change the value of weight to see both statements.
# (Make use of the < or > operators)