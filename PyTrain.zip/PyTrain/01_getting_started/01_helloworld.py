#!/usr/local/bin/python
import sys

print("Hellow, world")
print (sys.version)
print (sys.path)