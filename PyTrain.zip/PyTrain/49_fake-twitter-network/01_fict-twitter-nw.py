# fictional network of twitter users
# follower;followee
# WAP to method to find  whom a user is following
# WAP to method to find  who is following a user