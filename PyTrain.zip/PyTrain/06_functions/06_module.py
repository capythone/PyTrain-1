# import statement example to import standard module math

from example import *

a = b = 100
print("The value of pi is",add(a, b))


# # import module by renaming it
#
# import math as m print("The value of pi is", m.pi)