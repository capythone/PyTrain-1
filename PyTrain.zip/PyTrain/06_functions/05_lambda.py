#  Normal functions are defined using the def keyword,
# anonymous functions are defined using the lambda keyword.


# Program to show the use of lambda functions

double = lambda x: \
    x * 2


# Output: 10
print(double(5))