# delete a references
var1 = 1
var2 = 10

print (var1)
print (var2)

del var1 # delete the reference var1

print(var1)
print(var2)
