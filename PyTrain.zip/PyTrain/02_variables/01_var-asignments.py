#!/usr/bin/python3

counter = 100          # An integer assignment
miles   = 1000.0       # A floating point
name    = "John"       # A string

priyanka = True
print (counter)
print (miles)
print (name)
print ("Priyanaks' value ", priyanka)

#Multiple assigmentns
a = b = c = 1
print("Value of a ", a)
print("Value of b", b)
print("Value of c", c)

print("")
x, y, str = 1, 2, "john"
print("Value of x ", x)
print("Value of y", y)
print("Value of str", str)
