# f = open("test.txt",'r',encoding = 'utf-8')
f = open("HL-Data-Statim-Dev.pem",'r')
# f.read(4)
print(f.read())
# f.tell()
# f.seek(0)
#
# for line in f:
#     print(line, end = '')