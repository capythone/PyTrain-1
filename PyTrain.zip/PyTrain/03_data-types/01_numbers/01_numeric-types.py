
##### Numeric types int, float, complex

varInt = 1
varFloat = 10

print (varInt)
print (varFloat)

varCmplx = 3.89 + 1.4j

print(varCmplx)



x = 2
print(x)

print(x * x)
print(x == x)
print(x > 6)


# TODO: Exercises
# write a simple program that calculates how many minutes there are in seven weeks.