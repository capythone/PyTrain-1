dict = {}
dict['one'] = "This is one"
dict[2] = "This is two"
dict[4.5] = "This is two"
dict[1+4.5j] = "This is two"

list = [1,2,3]
dict[list] = "This is a list"

print(dict)
#
# tinydict = {'name': 'john','code':6734, 'dept': 'sales'}
#
#
# print (dict['one'])       # Prints value for 'one' key
# print (dict[2])           # Prints value for 2 key
# print (tinydict)          # Prints complete dictionary
#
#
# my_dict = {"book": "physical objects consisting of a number of pages bound together",
#            "sword": "a cutting or thrusting weapon that has a long metal blade",
#            "pie": "dish baked in pastry-lined pan often with a pastry top"}
#
# print(my_dict)
#
# description = my_dict["sword"]
# print(description)
#
#
# # keys(), values()
# # To retrieve a list of all the books we have in our collection, we can ask the dictionary to return its keys as a list:
#
# #Print only keys
# print (my_dict.keys())   # Prints all the keys
# print (my_dict.values()) # Prints all the values
#

# enclosed by curly braces ({ })
# values can be assigned and accessed using square braces ([])

#  What we learned ?
#  dictionary
# indexing or accessing keys of dictionaries
# adding items to a dictionary
# .keys()
# .values()

# TODO: Exercise Data type conversions
