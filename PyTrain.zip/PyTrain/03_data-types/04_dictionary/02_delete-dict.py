#!/usr/bin/python3

dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'}

del dict['Name'] # remove entry with key 'Name'
dict.clear()     # remove all entries in dict
del dict         # delete entire dictionary

print ("dict['Age']: ", dict['Age'])
print ("dict['School']: ", dict['School'])

# Properties
# 1) No duplicate keys
# 2) Keys must be immutable

dict = {['Name']: 'Zara', 'Age': 7}

print ("dict['Name']: ", dict['Name'])