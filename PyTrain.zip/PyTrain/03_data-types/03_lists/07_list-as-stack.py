stak = [3, 4, 5]
stak.append(6)
stak.append(7)

print(stak)
stak.pop()
print(stak)
