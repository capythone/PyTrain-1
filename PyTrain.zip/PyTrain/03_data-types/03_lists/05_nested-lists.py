nested_list = [ [9, 7, 3, 7],
                [9, 7, 12, 8],
                [9, 7, 7, 8]
                ]
nested_list.sort()
print(nested_list)

# print(nested_list[0][0])


# TODO: Exercise
# good_reads = []
# And add two books to it:
#
#[title, score]
#
# good_reads.append(["Pride and Prejudice", 8])
# good_reads.append(["A Clockwork Orange", 9])

# What we learned
# list
# mutable versus immutable
# .split()
# .append()
# nested lists
# .remove()
# .sort()
