list = ['physics', 'chemistry', 1997, 2000]

print (list)
del list[2]
print ("After deleting value at index 2 : ", list)
print ( "physics" in list)
print ( "maths" in list)

for x in list :
    print (x, end=',')