from collections import deque

queue = deque(["Eric", "John", "Michael"])

queue.append("Terry")
queue.append("Graham")
print(queue)

queue.popleft()
queue.popright()
print(queue)
