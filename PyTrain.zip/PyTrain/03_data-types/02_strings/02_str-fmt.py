#!/usr/bin/python3
name = 'Bond, James Bond'
print ("This is %s and nice to meet you" % (name))